class StringBuilder
{
    private _text: string = "";

    public append(text: string)
    {
        this._text += text;
    }
    public toString(): string
    {
        return this._text;
    }
}

function toHtml(markdown: string): string
{
    let stringBuilder = new StringBuilder();
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        processMarkdownLine(markdownLine, stringBuilder);
    }

    return stringBuilder.toString();
}

function processMarkdownLine(markdownLine: string, stringBuilder: StringBuilder)
{
    if(markdownLine.startsWith("# "))
    {
        headingToHtml(markdownLine, stringBuilder);
    }
    else
    {
        paragraphToHtml(markdownLine, stringBuilder);
    }
}

function headingToHtml(markdownLine: string, stringBuilder: StringBuilder)
{
    stringBuilder.append("<h1>");

    inlineMarkdownToHtml(markdownLine.substring(2), stringBuilder);

    stringBuilder.append("</h1>");
}
function paragraphToHtml(markdownLine: string, stringBuilder: StringBuilder)
{
    stringBuilder.append("<p>");
    
    inlineMarkdownToHtml(markdownLine, stringBuilder);

    stringBuilder.append("</p>");
}

// START: Modified function
function inlineMarkdownToHtml(markdownText: string, stringBuilder: StringBuilder)
{
    let lastUnconsumedChar: string | null = null;
    let emTagOpened = false;
    let strongTagOpened = false;

    // iterate through the characters
    for(let char of markdownText.split(""))
    {
        // a * triggers the beginning or end of italicized/bold text
        if(char == "*")
        {
            if(lastUnconsumedChar == "*")
            {
                // **, so dealing with bold text
                if(!strongTagOpened)
                {
                    stringBuilder.append("<strong>");
                    strongTagOpened = true;
                }
                else
                {
                    stringBuilder.append("</strong>");
                    strongTagOpened = false;
                }

                lastUnconsumedChar = null;
            }
            else
            {
                lastUnconsumedChar = char;
            }
        }
        else
        {
            // *, so dealing with italic text
            if(lastUnconsumedChar == "*")
            {
                if(!emTagOpened)
                {
                    stringBuilder.append(`<em>${char}`);
                    emTagOpened = true;
                }
                else
                {
                    stringBuilder.append(`</em>${char}`);
                    emTagOpened = false;
                }
            }
            else
            {
                stringBuilder.append(char);
            }

            lastUnconsumedChar = null;
        }
    }
}
// END: Modified function

function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = toHtml(markdown);

    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}

check("Here comes a simple paragraph.",
      "<p>Here comes a simple paragraph.</p>");

check("# This is an example of Markdown",
      "<h1>This is an example of Markdown</h1>");

check("# This is an example of Markdown\nHere comes a simple paragraph.",
      "<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>");

check("This is a paragraph with *italic* text.",
      "<p>This is a paragraph with <em>italic</em> text.</p>");

check("# This is *italic* text",
      "<h1>This is <em>italic</em> text</h1>");

// START: New tests
check("This is a paragraph with **bold** text.",
      "<p>This is a paragraph with <strong>bold</strong> text.</p>");
      
check("# This is a heading with **bold** text.",
      "<h1>This is a heading with <strong>bold</strong> text.</h1>");  
// END: New tests