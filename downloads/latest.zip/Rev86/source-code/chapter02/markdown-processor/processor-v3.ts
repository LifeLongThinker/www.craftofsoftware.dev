// START: Extended Implementation
function toHtml(markdown: string): string
{
    let html = "";
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        if(markdownLine.startsWith("# "))
        {
            html += `<h1>${markdownLine.substring(2)}</h1>`;
        }
        else
        {
            html += `<p>${markdownLine}</p>`;
        }
    }

    return html;
}
// END: Extended Implementation

const htmlForParagraph = toHtml("Here comes a simple paragraph.");
console.log(htmlForParagraph);

const htmlForHeading = toHtml("# This is an example of Markdown");
console.log(htmlForHeading);

// START: New Test
const html = toHtml(`# This is an example of Markdown
Here comes a simple paragraph.`);
console.log(html);
// END: New Test