function toHtml(markdown: string): string
{
    let html = "";
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        if(markdownLine.startsWith("# "))
        {
            html += `<h1>${markdownLine.substring(2)}</h1>`;
        }
        else
        {
            html += `<p>${markdownLine}</p>`;
        }
    }

    return html;
}

// START: New Check Function
function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = toHtml(markdown);

    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}
// END: New Check Function

// START: Refactored Tests
check("Here comes a simple paragraph.",
      "<p>Here comes a simple paragraph.</p>");

check("# This is an example of Markdown",
      "<h1>This is an example of Markdown</h1>");

check("# This is an example of Markdown\nHere comes a simple paragraph.",
      "<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>");
// END: Refactored Tests