// START: HTML Domain
class HtmlBuilder
{
    private _html = "";
    private _stack: string[] = [];

    constructor() {}
    
    private get isStackEmpty(): boolean
    {
        return this._stack.length == 0;
    }
    
    public peek(): string | null
    {
        if(this.isStackEmpty)
        {
            return null;
        }
        
        return this._stack[this._stack.length - 1];
    }
    public push(tag: string)
    {
        this.makeSureTagIsValidOrThrow(tag);

        const normalizedTag = this.normalize(tag);
        this._stack.push(normalizedTag);
        this._html += `<${normalizedTag}>`;
    }
    public pop(tag: string)
    {
        if(this.isStackEmpty)
        {
            throw new Error("Stack empty, nothing to pop.");
        }

        this.makeSureTagIsValidOrThrow(tag);
        const normalizedTag = this.normalize(tag);

        if(!this.canPop(normalizedTag))
        {
            throw new Error(`Must close tag <${this.peek()}> first.`);
        }

        this._stack.pop();
        this._html += `</${normalizedTag}>`;
    }
    public popRemaining()
    {
        while(!this.isStackEmpty)
        {
            const peekedTag = this.peek()!;
            this.pop(peekedTag);
        }
    }
    public write(text: string)
    {
        // TODO: we should validate the input here and escape special characters
        this.makeSureTextIsValidOrThrow(text);
        this._html += text;
    }
    public toHtml(): string
    {
        return this._html;
    }

    private canPop(normalizedTag: string)
    {
        return this.peek() == normalizedTag;
    }
    private normalize(tag: string): string
    {
        return tag.trim().toLowerCase();
    }
    private makeSureTagIsValidOrThrow(tag: string)
    {
        const validTagRegex = /^[a-z][a-z0-9]*$/im;

        if(!validTagRegex.test(tag))
        {
            throw new Error(`Invalid tag: ${tag}`);
        }
    }
    private makeSureTextIsValidOrThrow(text: string)
    {
        const validTextRegex = /[^<>]*/im;

        if(!validTextRegex.test(text))
        {
            throw new Error(`Invalid text: ${text}`);
        }
    }
}
// END: HTML Domain

// START: Text Domain
class Char
{
    constructor(
        public readonly value: string)
    {}

    public is(char: Char): boolean
    {
        return this.value == char.value;
    }
}
class Chars
{
    public static readonly NewLine = new Char("\n");
}
class CharStream
{
    private _normalizedText: string;
    private _position = -1;

    constructor(text: string)
    {
        this._normalizedText = CharStream.normalize(text);
    }

    public get length(): number
    {
        return this._normalizedText.length;
    }
    public get isEmpty(): boolean
    {
        return this.length == 0;
    }
    public get isAtStart(): boolean
    {
        return this.isEmpty
            || this._position == 0;
    }
    public get hasReachedEndOfStream(): boolean
    {
        return this.isEmpty
            || this._position >= this.length;
    }
    public get hasReachedEndOfLine(): boolean
    {
        return this.currentChar.is(Chars.NewLine)
            || this.isLastCharOfStream;
    }
    public get isLastCharOfStream(): boolean
    {
        return !this.isEmpty
            && this.hasReachedEndOfStream;
    }
    public get isFirstCharOfStream(): boolean
    {
        return !this.isEmpty
            && this.isAtStart;
    }
    public get isFirstCharOfLine(): boolean
    {
        return this.isFirstCharOfStream
            || this.peek(-1).is(Chars.NewLine);
    }
    public get currentChar(): Char
    {
        return this.getCharAtPosition(this._position);
    }

    public tryConsume(value: string): boolean
    {
        if(!(value?.length > 0))
        {
            throw new Error("Value must not be empty or null.");
        }

        for(var i = 0; i < value.length; i++)
        {
            const expectedChar = value.substring(i, i + 1);
            const givenChar = this.peek(i).value;
            
            if(givenChar != expectedChar)
            {
                return false;
            }
        }

        this.advance(value.length - 1);
        return true;
    }
    public advance(range?: number): boolean
    {
        range ??= 1;

        if(this.hasReachedEndOfStream)
        {
            return false;
        }
        
        this._position += range;
        return true;
    }

    private peek(offset: number): Char
    {
        return this.getCharAtPosition(this._position + offset);
    }
    private getCharAtPosition(position: number): Char
    {
        if(   position < 0 
           || position >= this.length)
        {
            throw new Error("End of stream reached.");
        }

        var value = this._normalizedText.substring(position, position + 1);
        return new Char(value);
    }
    private static normalize(text: string): string
    {
        // normalize new lines across platforms
        return (text ?? "").replace("\r", "");
    }
}
// END: Text Domain

// START: Markdown Domain
class Token
{
    constructor(
        public readonly value: string)
    {}

    public is(token: Token): boolean
    {
        return this.value == token.value;
    }
}
class Tokens
{
    public static readonly SingleEmphasis = new Token("*");
    public static readonly DoubleEmphasis = new Token("**");
    public static readonly PrimaryHeading = new Token("# ");
    public static readonly SecondaryHeading = new Token("## ");
    public static readonly EndOfLine = new Token("\endofline");
    public static readonly BeginningOfStream = new Token("\beginningofstream");
    public static readonly EndOfStream = new Token("\endofstream");
}
class Tokenizer
{
    private _currentToken: Token = Tokens.BeginningOfStream;

    constructor(
        private readonly _charStream: CharStream)
    {}
    
    public get currentToken(): Token
    {
        return this._currentToken;
    }
    public get hasReachedEndOfStream(): boolean
    {
        return this._currentToken == Tokens.EndOfStream;
    }

    public advanceToNextToken(): boolean
    {
        if(this.hasReachedEndOfStream)
        {
            return false;
        }

        this._charStream.advance();
        this._currentToken = this.getToken();
        return true;
    }

    private getToken(): Token
    {
        if(this._charStream.hasReachedEndOfStream)
        {
            return Tokens.EndOfStream;
        }
        else if(this._charStream.hasReachedEndOfLine)
        {
            return Tokens.EndOfLine;
        }
        else if(   this._charStream.isFirstCharOfLine
                && this._charStream.tryConsume(Tokens.PrimaryHeading.value))
        {
            return Tokens.PrimaryHeading;
        }
        else if(   this._charStream.isFirstCharOfLine
                && this._charStream.tryConsume(Tokens.SecondaryHeading.value))
        {
            return Tokens.SecondaryHeading;
        }
        else if(this._charStream.tryConsume(Tokens.DoubleEmphasis.value))
        {
            return Tokens.DoubleEmphasis;
        }
        else if(this._charStream.tryConsume(Tokens.SingleEmphasis.value))
        {
            return Tokens.SingleEmphasis;
        }
        
        // when other options are exhausted, this must be a literal token
        return new Token(this._charStream.currentChar.value);
    }
}
// END: Markdown Domain

// START: Markdown Processor
class MarkdownProcessor
{
    public static toHtml(markdown: string): string
    {
        const charStream = new CharStream(markdown);
        const tokenizer = new Tokenizer(charStream);
        const htmlBuilder = new HtmlBuilder();

        while(tokenizer.advanceToNextToken())
        {
            this.translateTokenToHtml(tokenizer.currentToken, htmlBuilder);
        }

        htmlBuilder.popRemaining();

        return htmlBuilder.toHtml();
    }

    private static translateTokenToHtml(token: Token, htmlBuilder: HtmlBuilder)
    {
        if(token.is(Tokens.PrimaryHeading))
        {
            htmlBuilder.push("h1");
        }
        else if(token.is(Tokens.SecondaryHeading))
        {
            htmlBuilder.push("h2");
        }
        else if(token.is(Tokens.EndOfLine))
        {
            // headings and paragraphs are terminated at the end of a line
            const topmostItem = htmlBuilder.peek();

            if(topmostItem && 
               ["h1", "h2", "p"].includes(topmostItem))
            {
                htmlBuilder.pop(topmostItem);
            }
        }
        else if(token.is(Tokens.SingleEmphasis))
        {
            // if we already have an <em> tag on the stack, 
            // this * will close it, otherwise we open it
            if(htmlBuilder.peek() == "em")
            {
                htmlBuilder.pop("em");
            }
            else
            {
                htmlBuilder.push("em");
            }
        }
        else if(token.is(Tokens.DoubleEmphasis))
        {
            // if we already have a <strong> tag on the stack, 
            // this ** will close it, otherwise we open it
            if(htmlBuilder.peek() == "strong")
            {
                htmlBuilder.pop("strong");
            }
            else
            {
                htmlBuilder.push("strong");
            }
        }
        else if(!token.is(Tokens.EndOfStream))
        {
            if(htmlBuilder.peek() == null)
            {
                htmlBuilder.push("p");
            }
            
            htmlBuilder.write(token.value!);
        }
    }
}
// END: Markdown Processor

function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = MarkdownProcessor.toHtml(markdown);
    
    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}

check('# This is an example of Markdown',
      '<h1>This is an example of Markdown</h1>');

check('## This is an example of Markdown',
      '<h2>This is an example of Markdown</h2>');

check('Here comes a simple paragraph.',
      '<p>Here comes a simple paragraph.</p>');

check('# This is an example of Markdown\nHere comes a simple paragraph.',
      '<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>');

check('This is a paragraph with *italic* text.',
      '<p>This is a paragraph with <em>italic</em> text.</p>');

check('# This is *italic* text',
      '<h1>This is <em>italic</em> text</h1>');

check('This is a paragraph with **bold** text.',
      '<p>This is a paragraph with <strong>bold</strong> text.</p>');

check('# This is a heading with **bold** text.',
      '<h1>This is a heading with <strong>bold</strong> text.</h1>');

check('# This is a heading with **bold** and *italic* text.',
      '<h1>This is a heading with <strong>bold</strong> and <em>italic</em> text.</h1>');