class StringBuilder
{
    private _text: string = "";

    public append(text: string)
    {
        this._text += text;
    }
    public toString(): string
    {
        return this._text;
    }
}

function toHtml(markdown: string): string
{
    let stringBuilder = new StringBuilder();
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        processMarkdownLine(markdownLine, stringBuilder);
    }

    return stringBuilder.toString();
}

function processMarkdownLine(markdownLine: string, stringBuilder: StringBuilder)
{
    if(markdownLine.startsWith("# "))
    {
        headingToHtml(markdownLine, stringBuilder);
    }
    else
    {
        paragraphToHtml(markdownLine, stringBuilder);
    }
}

// START: Modified functions
function headingToHtml(markdownLine: string, stringBuilder: StringBuilder)
{
    stringBuilder.append("<h1>");

    inlineMarkdownToHtml(markdownLine.substring(2), stringBuilder);

    stringBuilder.append("</h1>");
}
function paragraphToHtml(markdownLine: string, stringBuilder: StringBuilder)
{
    stringBuilder.append("<p>");
    
    inlineMarkdownToHtml(markdownLine, stringBuilder);

    stringBuilder.append("</p>");
}
// END: Modified functions

// START: Extracted function
function inlineMarkdownToHtml(markdownText: string, stringBuilder: StringBuilder)
{
    let emTagOpened = false;
    
    // iterate through the characters
    for(let char of markdownText.split(""))
    {
        // a * triggers the beginning or end of italicized text
        if(char == "*")
        {
            if(!emTagOpened)
            {
                stringBuilder.append("<em>");
                emTagOpened = true;
            }
            else
            {
                stringBuilder.append("</em>");
                emTagOpened = false;
            }
        }
        else
        {
            stringBuilder.append(char);
        }
    }
}
// END: Extracted function

function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = toHtml(markdown);

    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}

check("Here comes a simple paragraph.",
      "<p>Here comes a simple paragraph.</p>");

check("# This is an example of Markdown",
      "<h1>This is an example of Markdown</h1>");

check("# This is an example of Markdown\nHere comes a simple paragraph.",
      "<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>");

check("This is a paragraph with *italic* text.",
      "<p>This is a paragraph with <em>italic</em> text.</p>");

// START: New Test
check("# This is *italic* text",
      "<h1>This is <em>italic</em> text</h1>");
// END: New Test