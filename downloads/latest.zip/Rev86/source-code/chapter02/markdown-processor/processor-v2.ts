// START: Extended Implementation
function toHtml(markdownLine: string): string
{
    if(markdownLine.startsWith("# "))
    {
        return `<h1>${markdownLine.substring(2)}</h1>`;
    }
    
    return `<p>${markdownLine}</p>`;
}
// END: Extended Implementation

const htmlForParagraph = toHtml("Here comes a simple paragraph.");
console.log(htmlForParagraph);

// START: New Test
const htmlForHeading = toHtml("# This is an example of Markdown");
console.log(htmlForHeading);
// END: New Test