function toHtml(markdownLine: string): string
{
    return `<p>${markdownLine}</p>`;
}

const html = toHtml("Here comes a simple paragraph.");
console.log(html);