// START: StringBuilder Implementation
class StringBuilder
{
    private _text: string = "";

    public append(text: string)
    {
        this._text += text;
    }
    public toString(): string
    {
        return this._text;
    }
}
// END: StringBuilder Implementation

// START: New Implementation
function toHtml(markdown: string): string
{
    const stringBuilder = new StringBuilder();
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        processMarkdownLine(markdownLine, stringBuilder);
    }

    return stringBuilder.toString();
}
// END: New Implementation

// START: New Markdown Line Processing
function processMarkdownLine(markdownLine: string, stringBuilder: StringBuilder)
{
    if(markdownLine.startsWith("# "))
    {
        stringBuilder.append(`<h1>${markdownLine.substring(2)}</h1>`);
    }
    else
    {
        // here begins the paragraph
        stringBuilder.append("<p>");
        
        let emTagOpened = false;
        
        // iterate through the characters
        for(let char of markdownLine.split(""))
        {
            // a * triggers the beginning or end of italicized text
            if(char == "*")
            {
                if(!emTagOpened)
                {
                    stringBuilder.append("<em>");
                    emTagOpened = true;
                }
                else
                {
                    stringBuilder.append("</em>");
                    emTagOpened = false;
                }
            }
            else
            {
                stringBuilder.append(char);
            }
        }

        // here ends the paragraph
        stringBuilder.append("</p>");
    }
}
// END: New Markdown Line Processing

function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = toHtml(markdown);

    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}

check("Here comes a simple paragraph.",
      "<p>Here comes a simple paragraph.</p>");

check("# This is an example of Markdown",
      "<h1>This is an example of Markdown</h1>");

check("# This is an example of Markdown\nHere comes a simple paragraph.",
      "<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>");

check("This is a paragraph with *italic* text.",
      "<p>This is a paragraph with <em>italic</em> text.</p>");