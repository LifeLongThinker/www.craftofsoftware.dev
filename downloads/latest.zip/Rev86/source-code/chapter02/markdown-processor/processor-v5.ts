// START: Extended Implementation
function toHtml(markdown: string): string
{
    let html = "";
    const markdownLines = markdown.split("\n");

    for(const markdownLine of markdownLines)
    {
        if(markdownLine.startsWith("# "))
        {
            html += `<h1>${markdownLine.substring(2)}</h1>`;
        }
        else
        {
            // here begins the paragraph
            html += '<p>';
            
            let emTagOpened = false;
            
            // iterate through the characters
            for(let char of markdownLine.split(""))
            {
                // a * triggers the beginning or end of italicized text
                if(char == "*")
                {
                    if(!emTagOpened)
                    {
                        html += "<em>";
                        emTagOpened = true;
                    }
                    else
                    {
                        html += "</em>";
                        emTagOpened = false;
                    }
                }
                else
                {
                    html += char;
                }
            }

            // here ends the paragraph
            html += '</p>';
        }
    }

    return html;
}
// END: Extended Implementation

function check(markdown: string, expectedHtml: string)
{
    const generatedHtml = toHtml(markdown);

    if(generatedHtml == expectedHtml)
    {
        console.info(`Test passed: ${markdown}`);
    }
    else
    {
        const errorMsg = [
            `Test failed: ${markdown}`,
            `   Expected: ${expectedHtml}`,
            `  Generated: ${generatedHtml}`
        ].join("\n");
        
        console.error(errorMsg);
    }
}

check("Here comes a simple paragraph.",
      "<p>Here comes a simple paragraph.</p>");

check("# This is an example of Markdown",
      "<h1>This is an example of Markdown</h1>");

check("# This is an example of Markdown\nHere comes a simple paragraph.",
      "<h1>This is an example of Markdown</h1><p>Here comes a simple paragraph.</p>");

// START: New Test
check("This is a paragraph with *italic* text.",
      "<p>This is a paragraph with <em>italic</em> text.</p>");
// END: New Test